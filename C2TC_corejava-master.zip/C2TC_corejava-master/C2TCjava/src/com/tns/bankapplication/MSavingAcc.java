package com.tns.bankapplication;

public abstract class MSavingAcc extends SavingAcc{


		MSavingAcc(int accNo, String accNm, float accBal, boolean isSalaried) {
			super(accNo, accNm, accBal, isSalaried);
			// TODO Auto-generated constructor stub
		}


		private float MINBAL;

		@Override
		public void withdraw() {
			// TODO Auto-generated method stub
			return ;

		}


		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return null;
		}



		}

